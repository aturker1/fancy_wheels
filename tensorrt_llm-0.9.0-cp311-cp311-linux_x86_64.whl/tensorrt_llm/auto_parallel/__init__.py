from .auto_parallel import AutoParallelConfig, auto_parallel

__all__ = [
    'auto_parallel',
    'AutoParallelConfig',
]
